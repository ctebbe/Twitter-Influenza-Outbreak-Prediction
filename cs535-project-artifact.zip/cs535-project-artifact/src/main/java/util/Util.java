package util;

import backtype.storm.Config;
import backtype.storm.Constants;
import backtype.storm.tuple.Tuple;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by ctebbe
 */
public class Util {

    public static final String REGEX = "/#flu|[F|f]lu|[I|i]nfluenza|[H|h][1|3|7][N|n][1|3|9]/g";
    public static final String REGEX1 = ".*([H|h][1|3|7][N|n][1|3|9]).*";
    public static final String REGEX2 = ".*ILI.*|flu|[F|f]lu|.*[I|i]nfluenza.*|.*[F|f]lu[A-Z ,].*";

    public static String getTimeStamp() {
        return new SimpleDateFormat("HH:mm:ss:SS").format(new Date());
    }

    public static boolean isTickTuple(Tuple tuple) {
        return tuple.getSourceComponent().equals(Constants.SYSTEM_COMPONENT_ID)
            && tuple.getSourceStreamId().equals(Constants.SYSTEM_TICK_STREAM_ID);
    }

    public static Config getEmitFrequencyConfig() {
        Config conf = new Config();
        conf.put(Config.TOPOLOGY_TICK_TUPLE_FREQ_SECS, 10);
        return conf;
    }
    
    private static ArrayList<Integer> loadILIHistory(String dirPath){
    	try{
	    	ArrayList<Integer> pastILI = new ArrayList<Integer>();
    		String filename = dirPath.endsWith("/") ? dirPath + "ili.csv" : dirPath + "/ili.csv";
	    	FileReader fr = new FileReader(new File(filename));
	    	BufferedReader br = new BufferedReader(fr);
	    	String line = br.readLine();
	    	while(line != null){
	    		String[] columns = line.split(",");
	    		if(columns.length == 4)
	    			pastILI.add(Integer.parseInt(columns[2].trim()));
	    		line = br.readLine();
	    	}
	    	br.close();
	    	return pastILI;
    	} catch(Exception e){
    		System.err.println("Failed to load ili history");
    	}
    	return null;
    }
    
    private static ArrayList<Integer> loadTweetHistory(String dirPath){
    	try{
	    	ArrayList<Integer> pastTweets = new ArrayList<Integer>();
    		String filename = dirPath.endsWith("/") ? dirPath + "tweets.csv" : dirPath + "/tweets.csv";
	    	FileReader fr = new FileReader(new File(filename));
	    	BufferedReader br = new BufferedReader(fr);
	    	String line = br.readLine();
	    	while(line != null){
	    		String[] columns = line.split(",");
	    		if(columns.length == 4)
	    			pastTweets.add((int)(Double.parseDouble(columns[2].trim())*100000.0*100/Integer.parseInt(columns[3].trim())));
	    		line = br.readLine();
	    	}
	    	br.close();
	    	return pastTweets;
    	} catch(Exception e){
    		System.err.println("Failed to load ili history");
    	}
    	return null;
    }
    
    private static int getWeekNumber(){
    	return Calendar.getInstance(TimeZone.getTimeZone("PST")).get(Calendar.WEEK_OF_YEAR);
    }
    
    private static int predict(ArrayList<Integer> pastTweets, ArrayList<Integer> pastILI, int ilicount, int tweetCount) {
    	Integer tweets[] = pastTweets.subList(pastTweets.size()-4, pastTweets.size()).toArray(new Integer[4]);
    	Integer ili[] = pastTweets.subList(pastILI.size()-4, pastILI.size()).toArray(new Integer[4]);
    	int currentTweets = (int)(ilicount*100000.0*100/tweetCount);
    	return (int)(tweets[0]*0.02912 + tweets[1]*0.04241 + tweets[2]*0.058 + tweets[3]*0.0438 - currentTweets*0.01647 + ili[0]*0.11033 - ili[1]*0.17594 - ili[2]*0.15163 + ili[3]*1.16414 + 507.5797);
    }
    
    public static void main(String[] args){
    	//2015,24,712,59283
    	//2015,24,36,447594
    	System.out.println(predict(loadTweetHistory("C:/Users/JohnsonCharles/Desktop"), loadILIHistory("C:/Users/JohnsonCharles/Desktop"), 36, 447594));
    }
}
