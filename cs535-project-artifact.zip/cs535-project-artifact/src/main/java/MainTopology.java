import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.topology.TopologyBuilder;
import bolts.ThresholdBolt;
import spout.SimulatorSpout;
import spout.TwitterSpout;

/**
 * Created by ct.
 */
public class MainTopology {

    public static void main(String[] args) {
        TopologyBuilder builder = new TopologyBuilder();
        Config conf = new Config();
        //args[1] must be a directory where ili.csv and tweets.csv is present
        //args[2] is a simulation directory path
        if(args.length == 2){
        	builder.setSpout("spout", new TwitterSpout());
        } else {
        	builder.setSpout("spout", new SimulatorSpout());
        	conf.put("bz2dirpath", args[2]);
        }
        String tweetLog = args[1].endsWith("/")? args[1] + "tweets.log" : args[1] + "/" + "tweets.log";
        builder.setBolt("log", new ThresholdBolt(tweetLog, args[1])).shuffleGrouping("spout");
        conf.put("threshold", args[0]);
        conf.setDebug(false);
        LocalCluster cluster = new LocalCluster();
        cluster.submitTopology("twitter", conf, builder.createTopology());
    }
}
