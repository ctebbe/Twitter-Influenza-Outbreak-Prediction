package model;

import java.io.Serializable;
import java.util.ArrayList;

import util.Util;

public class Tweet implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String createdAt;
	private ArrayList<String> hashtags;
	
	public Tweet(String time, ArrayList<String> tags){
		this.createdAt = time;
		this.hashtags = tags;
	}
	
	public boolean isILITweet(){
		for(String hashtag : hashtags)
			if(hashtag.matches(Util.REGEX1) || hashtag.matches(Util.REGEX2))
				return true;
		return false;
	}
	
	public String getCreatedAt() {
		return createdAt;
	}
	
	public ArrayList<String> getHashtags() {
		return hashtags;
	}
	
	@Override
	public String toString() {
		return createdAt + ":" + hashtags.toString();
	}
	
}
