package bolts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Map;
import java.util.TimeZone;

import model.Tweet;
import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;

/**
 * Created by ct.
 */
public class ThresholdBolt extends BaseRichBolt {

    private PrintWriter writer;
    private final String filename;
    private OutputCollector collector;
    private int threshold;
    private long lastTime;
    private long ilicount;
    private long tweetCount;
    private int startWeek;
    private ArrayList<Integer> pastTweets;
    private ArrayList<Integer> pastILI;
    private PrintWriter boltLogger; 
    
    public ThresholdBolt(String filename, String dirPath) {
        this.filename = filename;
        this.ilicount = 0;
        this.tweetCount = 0;
        this.lastTime = System.currentTimeMillis();
        this.startWeek = this.getWeekNumber();
        this.pastILI = this.loadILIHistory(dirPath);
        this.pastTweets = this.loadTweetHistory(dirPath);
        String boltLog = dirPath.endsWith("/") ? dirPath + "bolt.log" : dirPath + "/bolt.log";
        try {
			this.boltLogger = new PrintWriter(new File(boltLog));
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    private ArrayList<Integer> loadILIHistory(String dirPath){
    	try{
	    	ArrayList<Integer> pastILI = new ArrayList<Integer>();
    		String filename = dirPath.endsWith("/") ? dirPath + "ili.csv" : dirPath + "/ili.csv";
	    	FileReader fr = new FileReader(new File(filename));
	    	BufferedReader br = new BufferedReader(fr);
	    	String line = br.readLine();
	    	while(line != null){
	    		String[] columns = line.split(",");
	    		if(columns.length == 4)
	    			pastILI.add(Integer.parseInt(columns[2].trim()));
	    		line = br.readLine();
	    	}
	    	br.close();
	    	return pastILI;
    	} catch(Exception e){
    		System.err.println("Failed to load ili history");
    	}
    	return null;
    }
    
    private ArrayList<Integer> loadTweetHistory(String dirPath){
    	try{
	    	ArrayList<Integer> pastTweets = new ArrayList<Integer>();
    		String filename = dirPath.endsWith("/") ? dirPath + "tweets.csv" : dirPath + "/tweets.csv";
	    	FileReader fr = new FileReader(new File(filename));
	    	BufferedReader br = new BufferedReader(fr);
	    	String line = br.readLine();
	    	while(line != null){
	    		String[] columns = line.split(",");
	    		if(columns.length == 4)
	    			pastTweets.add((int)(Double.parseDouble(columns[2].trim())*100000.0*100/Integer.parseInt(columns[3].trim())));
	    		line = br.readLine();
	    	}
	    	br.close();
	    	return pastTweets;
    	} catch(Exception e){
    		System.err.println("Failed to load ili history");
    	}
    	return null;
    }
    
    private int getWeekNumber(){
    	return Calendar.getInstance(TimeZone.getTimeZone("PST")).get(Calendar.WEEK_OF_YEAR);
    }
    
    private int predict() {
    	Integer tweets[] = (Integer[])this.pastTweets.subList(this.pastTweets.size()-4, this.pastTweets.size()).toArray(new Integer[4]);
    	Integer ili[] = (Integer[])this.pastILI.subList(this.pastILI.size()-4, this.pastILI.size()).toArray(new Integer[4]);
    	int currentTweets = (int)(this.ilicount*100000.0*100/this.tweetCount);
    	return (int)(tweets[0]*0.02912 + tweets[1]*0.04241 + tweets[2]*0.058 + tweets[3]*0.0438 - currentTweets*0.01647 + ili[0]*0.11033 - ili[1]*0.17594 - ili[2]*0.15163 + ili[3]*1.16414 + 507.5797);
    }

    public void prepare(@SuppressWarnings("rawtypes") Map map, TopologyContext topologyContext, OutputCollector outputCollector) {
        threshold = Integer.parseInt(map.get("threshold").toString().trim());
        collector = outputCollector;
        try {
            writer = new PrintWriter(filename,"UTF-8");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    public void execute(Tuple tuple) {
        Tweet tweet = (Tweet)tuple.getValueByField("message");
        if(null != tweet){
        	this.tweetCount++;
        	if(tweet.isILITweet()){
        		this.ilicount++;
        		writer.println(tweet.toString());
        		writer.flush();
        	}
        	if(System.currentTimeMillis() - lastTime >= 10000){
        		int prediction = this.predict();
        		if(prediction > this.threshold){
        			writer.println("*******THRESHOLD EXCEEDED**********");
        			writer.println("*******Predicted : " + prediction + " ***********");
        			writer.flush();
        		}
        		if(this.boltLogger != null){
					this.boltLogger.append("ilicount : " + ilicount +", tweetcount: " + tweetCount + "\n");
        		}
        	}
        	
        	if(getWeekNumber() - startWeek > 0){
        		startWeek = getWeekNumber();
        		this.lastTime = System.currentTimeMillis();
        		this.ilicount = 0;
        		this.tweetCount = 0;
        	}
        }
    }

    public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
    }

    public void cleanup() {
        this.writer.close();
        this.boltLogger.close();
        super.cleanup();
    }
}
