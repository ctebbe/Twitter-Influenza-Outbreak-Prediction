package spout;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;

import model.Tweet;

import org.apache.commons.compress.compressors.CompressorException;
import org.apache.commons.compress.compressors.CompressorInputStream;
import org.apache.commons.compress.compressors.CompressorStreamFactory;
import org.json.JSONArray;
import org.json.JSONObject;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

public class SimulatorSpout extends BaseRichSpout {


	private static final long serialVersionUID = 1L;
	private SpoutOutputCollector collector;
	private ArrayList<String> files;
	private int index;

	public void declareOutputFields(OutputFieldsDeclarer outputFieldsDeclarer) {
		outputFieldsDeclarer.declare(new Fields("message"));
	}

	public void open(@SuppressWarnings("rawtypes") Map map, TopologyContext topologyContext,
			SpoutOutputCollector spoutOutputCollector) {
		collector = spoutOutputCollector;
		this.index = 0;
		this.files = new ArrayList<String>();
		String dir = (String) map.get("bz2dirpath");
		if (dir.endsWith("/"))
			dir = dir.substring(0, dir.length() - 1);
		File f = new File(dir);
		if (f.isDirectory()) {
			String[] files = f.list();
			for (String file : files) {
				this.files.add(dir + "/" + file);
			}
		}
	}

	public BufferedReader getBufferedReaderForCompressedFile(String fileIn)
			throws FileNotFoundException, CompressorException {
		FileInputStream fin = new FileInputStream(fileIn);
		BufferedInputStream bis = new BufferedInputStream(fin);
		CompressorInputStream input = new CompressorStreamFactory()
				.createCompressorInputStream(bis);
		BufferedReader br = new BufferedReader(new InputStreamReader(input));
		return br;
	}

	public void nextTuple() {
		if (index < this.files.size()) {
			try {
				BufferedReader br = getBufferedReaderForCompressedFile(this.files
						.get(index));
				index++;
				String line;

				line = br.readLine();

				while (line != null) {
					JSONObject json = new JSONObject(line);
					String timezone = json.getJSONObject("user").getString(
							"time_zone");
					if ("Pacific Time (US & Canada)".equals(timezone)) {
						String time = json.getString("created_at");
						JSONArray hashtags = json.getJSONObject("entities")
								.getJSONArray("hashtags");
						ArrayList<String> tags = new ArrayList<String>();
						for (int i = 0; i < hashtags.length(); i++) {
							JSONObject hashtag = (JSONObject) hashtags.get(i);
							tags.add(hashtag.getString("text"));
						}
						collector.emit(new Values(new Tweet(time, tags)));
					}
					line = br.readLine();
				}
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (CompressorException e) {
				e.printStackTrace();
			} 
		}
	}

	public void close() {
		super.close();
	}
}