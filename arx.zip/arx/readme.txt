Instructions on how to run the program:
1. Place the files arx.py, ilitrain.csv,ilitest.csv,tweettrain.csv and tweettest.csv in a folder. 
2. Navigate to the folder in which the files are present and run the command "ipython arx.py"
3. Results are shown on the console and the graph will be saved to the same folder. 
